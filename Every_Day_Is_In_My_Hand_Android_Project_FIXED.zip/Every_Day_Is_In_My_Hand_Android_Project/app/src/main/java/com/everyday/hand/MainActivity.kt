package com.everyday.hand

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("app", MODE_PRIVATE) }
    private val entries = mutableMapOf<String, Entry>()
    private var month = Calendar.getInstance().get(Calendar.MONTH)
    private var year = Calendar.getInstance().get(Calendar.YEAR)
    private var page = "Calendar"
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var title: TextView
    private lateinit var nav: LinearLayout
    private val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    data class Entry(var type:String, var reason:String="")

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); load(); build(); showCalendar() }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun tv(text:String, size:Float, bold:Boolean=false): TextView = TextView(this).apply {
        this.text=text; textSize=size; setTextColor(Color.rgb(28,28,28)); if(bold) setTypeface(null,1); gravity=Gravity.CENTER_VERTICAL
    }
    private fun bg(color:Int, radius:Int=18, stroke:Int?=null): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); if(stroke!=null) setStroke(dp(1),stroke) }
    private fun button(text:String, onClick:()->Unit): TextView = tv(text,14f,true).apply { gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=bg(Color.rgb(34,181,167),24); setPadding(dp(18),0,dp(18),0); setOnClickListener{onClick()} }

    private fun build(){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(247,246,242))}
        val scroll=ScrollView(this); content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(14),dp(18),dp(14))}; scroll.addView(content)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL; setPadding(dp(8),dp(6),dp(8),dp(8)); setBackgroundColor(Color.WHITE)}
        listOf("Calendar","Semester","History","Me").forEach{n-> val b=tv(n,12f,true).apply{gravity=Gravity.CENTER; setPadding(0,dp(10),0,dp(8)); setOnClickListener{page=n; refresh()}}; nav.addView(b,LinearLayout.LayoutParams(0,dp(54),1f)) }
        root.addView(nav); setContentView(root)
    }
    private fun header(label:String){ content.removeAllViews(); title=tv(label,28f,true); content.addView(title,LinearLayout.LayoutParams(-1,dp(48))); }
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(16),dp(18),dp(16)); background=bg(Color.WHITE,22); layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(14)}}
    private fun refresh(){when(page){"Calendar"->showCalendar();"Semester"->showSemester();"History"->showHistory();"Me"->showMe()}}

    private fun showCalendar(){
        header("Every Day Is In My Hand")
        val summary=card(); val row=LinearLayout(this); row.orientation=LinearLayout.HORIZONTAL
        val total=workingDays(year,month); val present=countType(year,month,"Present"); val pct=if(total==0)0 else (present*100/total)
        val left=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; left.addView(tv("SEMESTER 1",12f,true)); left.addView(tv("$pct%",34f,true)); left.addView(tv("Attendance  •  75% target",13f)); row.addView(left,LinearLayout.LayoutParams(0,-2,1f))
        val prog=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=pct}; row.addView(prog,LinearLayout.LayoutParams(dp(110),dp(12)).apply{gravity=Gravity.CENTER_VERTICAL}); summary.addView(row)
        val small=tv("Tap a date to choose status. Saved dates use Edit to change.",12f).apply{setTextColor(Color.DKGRAY); setPadding(0,dp(8),0,0)}; summary.addView(small); content.addView(summary)
        val cal=card(); val top=LinearLayout(this); top.orientation=LinearLayout.HORIZONTAL
        val prev=button("‹"){changeMonth(-1)}; val next=button("›"){changeMonth(1)}
        top.addView(prev,LinearLayout.LayoutParams(dp(52),dp(42))); val mt=tv(SimpleDateFormat("MMMM yyyy",Locale.US).format(Calendar.getInstance().apply{set(year,month,1)}.time),20f,true).apply{gravity=Gravity.CENTER}; top.addView(mt,LinearLayout.LayoutParams(0,dp(42),1f)); top.addView(next,LinearLayout.LayoutParams(dp(52),dp(42))); cal.addView(top)
        val days=GridLayout(this).apply{columnCount=7;rowCount=1}; listOf("S","M","T","W","T","F","S").forEach{d->days.addView(tv(d,12f,true).apply{gravity=Gravity.CENTER;setTextColor(Color.GRAY)},GridLayout.LayoutParams().apply{width=0;height=dp(34);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)})}; cal.addView(days)
        val grid=GridLayout(this).apply{columnCount=7}
        val c=Calendar.getInstance(); c.set(year,month,1); val first=c.get(Calendar.DAY_OF_WEEK)-1; val max=c.getActualMaximum(Calendar.DAY_OF_MONTH)
        repeat(first){grid.addView(Space(this),GridLayout.LayoutParams().apply{width=0;height=dp(54);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)})}
        for(d in 1..max){ val key=key(d); val e=entries[key]; val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(2,2,2,2); background=bg(Color.WHITE,14);setOnClickListener{dateDialog(d)}}; cell.addView(tv("$d",15f,true).apply{gravity=Gravity.CENTER}); val dot=tv(if(e==null)"" else "●",12f,true).apply{gravity=Gravity.CENTER;setTextColor(typeColor(e?.type));minHeight=dp(18)}; cell.addView(dot); grid.addView(cell,GridLayout.LayoutParams().apply{width=0;height=dp(60);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(2),dp(2),dp(2),dp(2))}) }
        cal.addView(grid); content.addView(cal)
        val info=card(); info.addView(tv("This Month",16f,true)); val line=tv("Present  $present    •    Leave  ${countType(year,month,"Leave")}    •    Working days  $total",14f); line.setPadding(0,dp(8),0,0); info.addView(line); content.addView(info)
    }
    private fun typeColor(type:String?):Int=when(type){"Present"->Color.rgb(34,181,167);"Leave"->Color.rgb(228,107,107);"Holiday"->Color.rgb(213,162,58);"Internal Exam","Semester Exam"->Color.rgb(117,103,217);"Study Holiday","After Exam Holiday"->Color.rgb(60,140,190);else->Color.TRANSPARENT}
    private fun changeMonth(delta:Int){month+=delta;if(month<0){month=11;year--};if(month>11){month=0;year++};showCalendar()}
    private fun key(d:Int)=String.format(Locale.US,"%04d-%02d-%02d",year,month+1,d)

    private fun dateDialog(d:Int){
        val k=key(d); val old=entries[k]; val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(10),dp(20),0)}
        val t=tv("${SimpleDateFormat("dd MMM yyyy",Locale.US).format(Calendar.getInstance().apply{set(year,month,d)}.time)}",20f,true);box.addView(t)
        if(old!=null)box.addView(tv("Saved: ${old.type}${if(old.reason.isBlank())"" else " • "+old.reason}",13f).apply{setTextColor(Color.GRAY);setPadding(0,dp(6),0,dp(12))})
        val items=listOf("Present","Leave","Holiday","Internal Exam","Semester Exam","Study Holiday","After Exam Holiday","Edit","Clear")
        items.forEach{item->val b=TextView(this).apply{text=item;textSize=15f;setTextColor(Color.rgb(30,30,30));setPadding(dp(10),dp(13),dp(10),dp(13));setOnClickListener{if(item=="Edit"){showEditDialog(k,old)}else if(item=="Clear"){entries.remove(k);save();refresh()}else{showTypeDialog(k,item,old)}}};box.addView(b)}
        AlertDialog.Builder(this).setView(box).show()
    }
    private fun showTypeDialog(k:String,type:String,old:Entry?){
        if(type=="Present"||type.contains("Exam")||type.contains("Holiday")){ val reason=if(type=="Present")"" else (old?.reason ?: ""); saveEntry(k,type,reason); return }
        val input=EditText(this); input.hint="Reason (required)"; input.setText(old?.reason ?: ""); AlertDialog.Builder(this).setTitle("Leave reason").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_-> if(input.text.toString().trim().isNotEmpty())saveEntry(k,type,input.text.toString().trim()) else Toast.makeText(this,"Reason is required",Toast.LENGTH_SHORT).show()}.show()
    }
    private fun showEditDialog(k:String,old:Entry?){ if(old==null)return; val choices=arrayOf("Present","Leave","Holiday","Internal Exam","Semester Exam","Study Holiday","After Exam Holiday","Clear"); AlertDialog.Builder(this).setTitle("Edit date").setItems(choices){_,i-> if(choices[i]=="Clear"){entries.remove(k);save();refresh()}else showTypeDialog(k,choices[i],old)}.show() }
    private fun saveEntry(k:String,type:String,reason:String){entries[k]=Entry(type,reason);save();refresh()}

    private fun showSemester(){
        header("Semester")
        val c=card(); c.addView(tv("Semester 1",22f,true)); val start=prefs.getString("semStart",""); val end=prefs.getString("semEnd",""); c.addView(tv(if(start.isNullOrBlank())"Set semester dates to calculate" else "$start  →  $end",13f).apply{setTextColor(Color.GRAY);setPadding(0,dp(6),0,dp(12))}); val total=semesterWorking(); val p=semesterPresent(); val pct=if(total==0)0 else p*100/total; c.addView(tv("$pct%",38f,true)); c.addView(tv("Present $p  •  Working days $total  •  Leave ${semesterLeaves()}",14f).apply{setPadding(0,dp(6),0,dp(14))}); val set=button("Set / Edit Semester"){semesterDialog()};c.addView(set,LinearLayout.LayoutParams(-1,dp(46)));content.addView(c)
        val info=card(); info.addView(tv("Academic dates stay in the same calendar",16f,true)); info.addView(tv("Internal exam, semester exam, study holiday and after-exam holiday can be added later and edited.",13f).apply{setTextColor(Color.GRAY);setPadding(0,dp(8),0,0)});content.addView(info)
    }
    private fun semesterDialog(){ val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),0,dp(18),0)}; val s=EditText(this);s.hint="Start (yyyy-MM-dd)";s.setText(prefs.getString("semStart",""));val e=EditText(this);e.hint="End (yyyy-MM-dd)";e.setText(prefs.getString("semEnd",""));box.addView(s);box.addView(e);AlertDialog.Builder(this).setTitle("Semester 1").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->prefs.edit().putString("semStart",s.text.toString().trim()).putString("semEnd",e.text.toString().trim()).apply();showSemester()}.show() }
    private fun inSemester(k:String):Boolean{val s=prefs.getString("semStart","")?:"";val e=prefs.getString("semEnd","")?:"";return s.isBlank()||e.isBlank()||k in s..e}
    private fun semesterWorking()=entries.keys.filter{inSemester(it)}.count{entries[it]?.type=="Present"||entries[it]?.type=="Leave"}
    private fun semesterPresent()=entries.keys.filter{inSemester(it)}.count{entries[it]?.type=="Present"}
    private fun semesterLeaves()=entries.keys.filter{inSemester(it)}.count{entries[it]?.type=="Leave"}

    private fun showHistory(){header("History");if(entries.isEmpty()){content.addView(tv("No attendance history yet.",15f).apply{setPadding(0,dp(20),0,0)});return};entries.toSortedMap(reverseOrder()).forEach{(k,e)->val c=card();c.addView(tv(k,16f,true));c.addView(tv(e.type,15f).apply{setTextColor(typeColor(e.type));setPadding(0,dp(5),0,0)});if(e.reason.isNotBlank())c.addView(tv("Reason: ${e.reason}",13f).apply{setTextColor(Color.GRAY);setPadding(0,dp(4),0,dp(8))});val edit=button("Edit"){showEditDialog(k,e)};c.addView(edit,LinearLayout.LayoutParams(dp(110),dp(40)));content.addView(c)}}

    private fun showMe(){header("Me");val email=prefs.getString("email","") ?: "";if(email.isBlank()){val c=card();c.addView(tv("Your account",20f,true));c.addView(tv("Sign in or create an account to keep your profile on this device.",13f).apply{setTextColor(Color.GRAY);setPadding(0,dp(7),0,dp(14))});c.addView(button("Sign in / Create account"){accountDialog() },LinearLayout.LayoutParams(-1,dp(46)));content.addView(c)}else{val c=card();val name=prefs.getString("name","Student") ?: "Student";c.addView(tv(name,22f,true));c.addView(tv(email,13f).apply{setTextColor(Color.GRAY);setPadding(0,dp(4),0,dp(14))});c.addView(button("Sign out / Log out"){prefs.edit().remove("email").apply();showMe()},LinearLayout.LayoutParams(-1,dp(46)));content.addView(c)}}
    private fun accountDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),0,dp(18),0)};val n=EditText(this);n.hint="Name";val em=EditText(this);em.hint="Email";val pw=EditText(this);pw.hint="Password";pw.inputType=129;box.addView(n);box.addView(em);box.addView(pw);AlertDialog.Builder(this).setTitle("Sign in / Create account").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->prefs.edit().putString("name",n.text.toString().ifBlank{"Student"}).putString("email",em.text.toString().trim()).apply();showMe()}.show()}

    private fun workingDays(y:Int,m:Int):Int{val c=Calendar.getInstance();c.set(y,m,1);val max=c.getActualMaximum(Calendar.DAY_OF_MONTH);var n=0;for(d in 1..max){val dow=c.apply{set(y,m,d)}.get(Calendar.DAY_OF_WEEK);val e=entries[keyFor(y,m,d)];if(e?.type=="Present"||e?.type=="Leave")n++ else if(dow!=Calendar.SATURDAY&&dow!=Calendar.SUNDAY&&e?.type !in setOf("Holiday","Internal Exam","Semester Exam","Study Holiday","After Exam Holiday"))n++};return n}
    private fun countType(y:Int,m:Int,type:String)=entries.count{(k,v)->k.startsWith(String.format(Locale.US,"%04d-%02d-",y,m+1))&&v.type==type}
    private fun keyFor(y:Int,m:Int,d:Int)=String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d)
    private fun load(){entries.clear();val a=JSONArray(prefs.getString("entries","[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);entries[o.getString("date")]=Entry(o.getString("type"),o.optString("reason"))}}
    private fun save(){val a=JSONArray();entries.forEach{(k,v)->a.put(JSONObject().put("date",k).put("type",v.type).put("reason",v.reason))};prefs.edit().putString("entries",a.toString()).apply()}
}
